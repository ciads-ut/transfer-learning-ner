from __future__ import absolute_import
from keras.engine import Layer
from .. import backend as K
import numpy as np
